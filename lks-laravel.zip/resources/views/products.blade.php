@extends('layouts.dash')

@section('content')
<div class="card">
    <div class="header"><h4 class="title">Add Product</h4></div>
    <div class="content">
        <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Striped Table</h4>
                                <p class="category">Here is a subtitle for this table</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                             @if( $products )
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Salary</th>
                                        <th>Country</th>
                                        <th>City</th>
                                        <th>Action</th>
                                    </tr></thead>
                                    <tbody>
                                    @foreach( $products as $product )
                                        <tr>
                                            <td>{{ $product->id }}</td>
                                            <td>{{ $product->title }}</td>
                                            <td>{{ $product->description }}</td>
                                            <td>{{ $product->price }}</td>
                                            <td>{{ $product->created_at }}</td>
                                            <td><a href="javascript:void(0);" data-token="{{ csrf_token() }}" data-id="{{$product->id}}" class="delete-product">Delete</a></td>
                                        </tr>
                                    @endforeach    
                                    </tbody>
                                </table>
                            @endif
                            </div>
                        </div>
                    </div>

                </div>
            </div>        
    </div>
</div>
@endsection
