<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="header"><h4 class="title">Add Product</h4></div>
    <div class="content">
        <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Striped Table</h4>
                                <p class="category">Here is a subtitle for this table</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                             <?php if( $products ): ?>
                                <table class="table table-striped">
                                    <thead>
                                        <tr><th>ID</th>
                                        <th>Name</th>
                                        <th>Salary</th>
                                        <th>Country</th>
                                        <th>City</th>
                                        <th>Action</th>
                                    </tr></thead>
                                    <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($product->id); ?></td>
                                            <td><?php echo e($product->title); ?></td>
                                            <td><?php echo e($product->description); ?></td>
                                            <td><?php echo e($product->price); ?></td>
                                            <td><?php echo e($product->created_at); ?></td>
                                            <td><a href="javascript:void(0);" data-token="<?php echo e(csrf_token()); ?>" data-id="<?php echo e($product->id); ?>" class="delete-product">Delete</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    </tbody>
                                </table>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>