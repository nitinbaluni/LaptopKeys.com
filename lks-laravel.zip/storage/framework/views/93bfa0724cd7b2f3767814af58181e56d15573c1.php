<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="header"><h4 class="title">Add Product</h4></div>
    <div class="content">
        <form method="post" action="<?php echo e(route('create_product')); ?>">
        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
        <input name="author" type="hidden" value="1"/>
            <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Title</label>
                    <input type="text" class="form-control border-input" name="title"placeholder="Product Title" value="<?php echo e(old('title')); ?>">
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Description</label>
                    <textarea rows="5" class="form-control border-input" name="description" placeholder="Product description">
                    <?php echo e(old('description')); ?>

                    </textarea>
                    <?php if($errors->has('description')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Price</label>
                    <input type="text" class="form-control border-input" name="price" placeholder="Price" value="<?php echo e(old('price')); ?>">
                    <?php if($errors->has('price')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('price')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                </div>
            </div>
  
          <div class="row">
              <div class="col-md-6"><input type="submit" class="btn btn-info btn-fill btn-wd" value="Add Product"></div>
          </div>
            <div class="clearfix"></div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>