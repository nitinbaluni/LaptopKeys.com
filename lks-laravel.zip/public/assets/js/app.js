jQuery(document).ready(function($){
	$("a.delete-product").on( "click", function(){
		var id 		= $(this).data('id');
		var token 	= $(this).data('token');
        $.ajax({
            url: "/laravel/laptopkeys.com/dashboard/product/delete/"+id,
            type: 'DELETE',
            dataType: "JSON",
            data: { id: id, _method:'DELETE', _token: token},
            success: function (){
                console.log("it Work");
            }
        });
	});
});