<?php
namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Product;

class ProductController extends Controller{
    
    public function add_product( Request $request  ){
    	$this->validateInput( $request );
    	$created = Product::create([
            'author' 		=> Auth::user()->id,
            'title' 		=> $request['title'],
            'description' 	=> $request['description'],
            'price' 		=> $request['price'],
        ]);
        return response()->json(['created'=>$created]); 
    }

    private function validateInput( $request ){
    	$this->validate($request, [
            'title' 		=> 'required|unique:products',
            'description' 	=> 'required|max:60',
            'price' 		=> 'required|integer'
        ]);
    }

}
