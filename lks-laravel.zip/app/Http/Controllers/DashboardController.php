<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Product;

class DashboardController extends Controller
{	
	public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
    	return view('dashboard');
    }

    public function add_product( Request $request ){
    	$this->validateInput( $request );
    	$created = Product::create([
            'author' 		=> Auth::user()->id,
            'title' 		=> $request['title'],
            'description' 	=> $request['description'],
            'price' 		=> $request['price'],
        ]);
        //print_r( $created );
    	//return Redirect::back()->withInput(Input::all());
        return redirect()->intended('dashboard');
    }

    public function delete_product( $id, Request $request ){
    	if( $request->ajax() ){
    		echo $id;
    		exit();
    		/*$Product = new Product;
		    $Product = Product::find($id);
		    $Product->delete($id);
		    return response()->json([
		        'success' => 'Record has been deleted successfully!'
		    ]);*/
    	}	
    }

    public function product_list(){
    	$products = Product::where( 'author', Auth::user()->id )->get();
    	return view( 'products', ['products' => $products] );
    }

    private function validateInput($request) {
        $this->validate($request, [
            'title' 		=> 'required|unique:products',
            'description' 	=> 'required|max:60',
            'price' 		=> 'required|integer'
        ]);
    }
}